<?php
session_start();
 class vision1
 {
	 function selectContent($links)
		{
			  $query="select * from daimond";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['weight']=stripslashes($row['weight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['measurment']=stripslashes($row['measurment']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['oc']=stripslashes($row['oc']); 
				$infoArr[$i]['rf']=stripslashes($row['rf']); 
				$infoArr[$i]['sg']=stripslashes($row['sg']); 
				$infoArr[$i]['mo']=stripslashes($row['mo']); 
				$infoArr[$i]['species']=stripslashes($row['species']); 
				$infoArr[$i]['variety']=stripslashes($row['variety']); 
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
				$infoArr[$i]['tdepth']=stripslashes($row['tdepth']);
				$infoArr[$i]['fluorescence']=stripslashes($row['fluorescence']);
				 
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
		
		
		
    function selectbyStatus($links)
		{
			  $query="select * from vision where `status`=1";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['description']=stripslashes($row['description']); 
				$infoArr[$i]['grossweight']=stripslashes($row['grossweight']); 
				$infoArr[$i]['diamondweight']=stripslashes($row['diamondweight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['clarity']=stripslashes($row['clarity']); 
				 $infoArr[$i]['tdepth']=stripslashes($row['tdepth']);
				$infoArr[$i]['fluorescence']=stripslashes($row['fluorescence']);
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
	 
	 function single($id, $links)
		{
			  $query="select * from `daimond` where `c_no`='$id'";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['weight']=stripslashes($row['weight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['measurment']=stripslashes($row['measurment']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['oc']=stripslashes($row['oc']); 
				$infoArr[$i]['rf']=stripslashes($row['rf']); 
				$infoArr[$i]['sg']=stripslashes($row['sg']); 
				$infoArr[$i]['mo']=stripslashes($row['mo']); 
				$infoArr[$i]['species']=stripslashes($row['species']); 
				$infoArr[$i]['variety']=stripslashes($row['variety']); 
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
				$infoArr[$i]['tdepth']=stripslashes($row['tdepth']);
				$infoArr[$i]['fluorescence']=stripslashes($row['fluorescence']);
				 
				
				 
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
		
		
		
			
		
	function add($data, $links)
		{
			
			
	$c_no = $data['c_no'];
$category = $data['category'];
// $supplier = $data['supplier'];
$weight = $data['weight'];
$shape = $data['shape'];
$measurment = $data['measurment'];
$color = $data['color'];
$oc = $data['oc'];
$rf = $data['rf'];
$sg = $data['sg'];
$mo = $data['mo'];
$species = $data['species'];
$variety = $data['variety'];
$comment = $data['comment'];
$tdepth = $data['tdepth'];
$fluorescence = $data['fluorescence'];

			 
			 	 $imagefile='';
			 
			 if($_FILES['image']['name']!='') {
			     $img_name   = $_FILES['image']['name'];

        		$temp = $_FILES['image']['tmp_name'];
        
        		$ext = pathinfo($img_name, PATHINFO_EXTENSION);
        
        		$imagefile = time().'.'.$ext;
        
        		$target="../uploads/".$imagefile;
        
        		move_uploaded_file($temp,$target);
			 }
			 	
			 	
			 
			$query="INSERT INTO `daimond`(`c_no`, `category`, `weight`, `shape`, `measurment`, `color`, `oc`, `rf`, `sg`, `mo`, `species`, `variety`, `comment`,`tdepth`,`fluorescence`, `image`) VALUES ('$c_no','$category', '$weight','$shape','$measurment','$color','$oc','$rf','$sg','$mo','$species','$variety','$comment','$tdepth','$fluorescence', '$imagefile')";
 
			 $res=mysqli_query($links, $query);
			 if($res)
				 {
					    $_SESSION['msg']="Added  Successfully";
echo "<script>location='view-certificates1.php'</script>";					
				 }
			 else
			 	 {
					 	echo "<script>alert('Data Insertion failed');</script>";
		
				 }
		 }	
		
		function edit($data, $links)
			{
					$editID=base64_decode($data);
				    $query="select * from `daimond` where ID='$editID'";
					$res=mysqli_query($links, $query);
					$infoArr=array();
					$i=0;
					while($row=mysqli_fetch_assoc($res))
					{
					$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['weight']=stripslashes($row['weight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['measurment']=stripslashes($row['measurment']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['oc']=stripslashes($row['oc']); 
				$infoArr[$i]['rf']=stripslashes($row['rf']); 
				$infoArr[$i]['sg']=stripslashes($row['sg']); 
				$infoArr[$i]['mo']=stripslashes($row['mo']); 
				$infoArr[$i]['species']=stripslashes($row['species']); 
				$infoArr[$i]['variety']=stripslashes($row['variety']); 
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
				$infoArr[$i]['tdepth']=stripslashes($row['tdepth']);
				$infoArr[$i]['fluorescence']=stripslashes($row['fluorescence']);
				$infoArr[$i]['image']=$row['image'];
					}
				    // echo '<pre>'; print_r($infoArr); exit;
				    return ($infoArr);
			}
			
		function update($data, $links)
			{
			
			 $id=base64_decode($data['editid']);
		$c_no = $data['c_no'];
$category = $data['category'];
$supplier = $data['supplier'];
$weight = $data['weight'];
$shape = $data['shape'];
$measurment = $data['measurment'];
$color = $data['color'];
$oc = $data['oc'];
$rf = $data['rf'];
$sg = $data['sg'];
$mo = $data['mo'];
$species = $data['species'];
$variety = $data['variety'];
$comment = $data['comment'];
$tdepth = $data['tdepth'];
$fluorescence = $data['fluorescence'];

			 
			 	 if($_FILES['image']['name']!='') {
			     $img_name   = $_FILES['image']['name'];

        		$temp = $_FILES['image']['tmp_name'];
        
        		$ext = pathinfo($img_name, PATHINFO_EXTENSION);
        
        		$imagefile = time().'.'.$ext;
        
        		$target="../uploads/".$imagefile;
        
        		move_uploaded_file($temp,$target);
        		
        		
	            	$query="update `daimond` set `c_no`='$c_no', `weight`='$weight',`shape`='$shape',`measurment`='$measurment',`color`='$color',`oc`='$oc',`rf`='$rf',`sg`='$sg',`mo`='$mo',`species`='$species',`variety`='$variety',`comment`='$comment',`tdepth`='$tdepth',`fluorescence`='$fluorescence' ,`image`='$imagefile' where ID='$id'";
					
        		}
                else {
        		   $query="update `daimond` set `c_no`='$c_no', `weight`='$weight',`shape`='$shape',`measurment`='$measurment',`color`='$color',`oc`='$oc',`rf`='$rf',`sg`='$sg',`mo`='$mo',`species`='$species',`variety`='$variety',`comment`='$comment',`tdepth`='$tdepth',`fluorescence`='$fluorescence' where ID='$id'";

        		}
		 $res=mysqli_query($links, $query);
				
						if($res)
							{
								$_SESSION['msg']="Updated Successfully";
							   header('location:view-certificates1.php');
							}
							else
							{
								echo "<script>alert('Data Updation failed');</script>";
							}
				}
					
			
		function delete($data, $links)
			{	
			    $deleteID=base64_decode($data);
				$query="delete from `daimond` where ID='$deleteID'";
				$res=mysqli_query($links, $query);
				if($res)
					{
						$_SESSION['msg']="Deleted Successfully";
						header('location:view-certificates1.php');
					}
				else
					{
						echo "<script>alert('Data Deletion failed');</script>";
					}
			}
			
		
			
		
 }
 ?>