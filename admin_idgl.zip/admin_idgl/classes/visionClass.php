<?php
session_start();
 class vision
 {
	 function selectContent($links)
		{
			  $query="select * from vision";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['description']=stripslashes($row['description']); 
				$infoArr[$i]['design_no']=stripslashes($row['design_no']); 
				$infoArr[$i]['grossweight']=stripslashes($row['grossweight']); 
				$infoArr[$i]['diamondweight']=stripslashes($row['diamondweight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['no_of_diamon']=stripslashes($row['no_of_diamon']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['clarity']=stripslashes($row['clarity']); 
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
				
				 
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
		
		
		
    function selectbyStatus($links)
		{
			  $query="select * from vision where `status`=1";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['description']=stripslashes($row['description']); 
				$infoArr[$i]['grossweight']=stripslashes($row['grossweight']); 
				$infoArr[$i]['diamondweight']=stripslashes($row['diamondweight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['clarity']=stripslashes($row['clarity']); 
				 
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
	 
	 function single($id, $links)
		{
			  $query="select * from `vision` where `c_no`='$id'";
			 $res=mysqli_query($links, $query);
			 $infoArr=array();
			 $i=0;
			 while($row=mysqli_fetch_assoc($res))
			 {
				$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['description']=stripslashes($row['description']); 
				$infoArr[$i]['grossweight']=stripslashes($row['grossweight']); 
				$infoArr[$i]['diamondweight']=stripslashes($row['diamondweight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['clarity']=stripslashes($row['clarity']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['design_no']=stripslashes($row['design_no']); 
				$infoArr[$i]['no_of_diamon']=stripslashes($row['no_of_diamon']); 
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
				
				 
				$i++;	
			 }
		// echo '<pre>'; print_r($infoArr); exit;
			 return ($infoArr);
		}
		
		
		
			
		
	function add($data, $links)
		{
			
			
			
			$c_no = $data['c_no'];
$category = $data['category'];
$description = $data['description'];
$grossweight = $data['grossweight'];
$diamondweight = $data['diamondweight'];
$shape = $data['shape'];
$color = $data['color'];
$clarity = $data['clarity'];
// $supplier = $data['supplier'];
// $design_no = $data['design_no'];
// $no_of_diamon = $data['no_of_diamon'];
$comment = $data['comment'];

			 $imagefile='';
			 
			 if($_FILES['image']['name']!='') {
			     $img_name   = $_FILES['image']['name'];

        		$temp = $_FILES['image']['tmp_name'];
        
        		$ext = pathinfo($img_name, PATHINFO_EXTENSION);
        
        		$imagefile = time().'.'.$ext;
        
        		$target="../uploads/".$imagefile;
        
        		move_uploaded_file($temp,$target);
			 }
			 	
		
			$query="INSERT into `vision`( `c_no`, `description`, `grossweight`, `diamondweight`, `shape`, `color`, `clarity`,`category`, `comment`,`image`) values('$c_no','$description','$grossweight','$diamondweight','$shape','$color','$clarity','$category', '$comment','$imagefile')";
 

			 $res = mysqli_query($links, $query);
			 
			 if($res)
				 {
					    $_SESSION['msg']="Added  Successfully";
                        echo "<script>location='view-certificates.php'</script>";					
				 }
			 else
			 	 {
					 	echo "<script>alert('Data Insertion failed');</script>";
		
				 }
		 }	
		
		function edit($data, $links)
			{
					$editID=base64_decode($data);
				    $query="select * from `vision` where ID='$editID'";
					$res=mysqli_query($links, $query);
					$infoArr=array();
					$i=0;
					while($row=mysqli_fetch_assoc($res))
					{
					$infoArr[$i]['ID']=$row['ID']; 
				$infoArr[$i]['c_no']=stripslashes($row['c_no']); 
				$infoArr[$i]['description']=stripslashes($row['description']); 
				$infoArr[$i]['grossweight']=stripslashes($row['grossweight']); 
				$infoArr[$i]['diamondweight']=stripslashes($row['diamondweight']); 
				$infoArr[$i]['shape']=stripslashes($row['shape']); 
				$infoArr[$i]['color']=stripslashes($row['color']); 
				$infoArr[$i]['clarity']=stripslashes($row['clarity']); 
				$infoArr[$i]['category']=stripslashes($row['category']); 
				$infoArr[$i]['supplier']=stripslashes($row['supplier']); 
				$infoArr[$i]['design_no']=stripslashes($row['design_no']); 
				$infoArr[$i]['no_of_diamon']=stripslashes($row['no_of_diamon']); $infoArr[$i]['image']=$row['image'];
				$infoArr[$i]['comment']=stripslashes($row['comment']); 
					
					}
				    // echo '<pre>'; print_r($infoArr); exit;
				    return ($infoArr);
			}
			
		function update($data, $links)
			{
			
			 $id=base64_decode($data['editid']);
			 
			 $c_no = $data['c_no'];
$description = $data['description'];
$grossweight = $data['grossweight'];
$diamondweight = $data['diamondweight'];
$category = $data['category'];
$shape = $data['shape'];
$color = $data['color'];
$clarity = $data['clarity'];
// $supplier = $data['supplier'];
// $design_no = $data['design_no'];
// $no_of_diamon = $data['no_of_diamon'];
$comment = $data['comment'];

			 
			 
		
			 if($_FILES['image']['name']!='') {
			     $img_name   = $_FILES['image']['name'];

        		$temp = $_FILES['image']['tmp_name'];
        
        		$ext = pathinfo($img_name, PATHINFO_EXTENSION);
        
        		$imagefile = time().'.'.$ext;
        
        		$target="../uploads/".$imagefile;
        
        		move_uploaded_file($temp,$target);
        		
        			$query="update `vision` set `c_no`='$c_no',`description`='$description',`grossweight`='$grossweight',`diamondweight`='$diamondweight',`shape`='$shape',`color`='$color',`clarity`='$clarity',`category`='$category', `comment`='$comment',`image`='$imagefile' where ID='$id'";
			 }
			 else {
			     $query="update `vision` set `c_no`='$c_no',`description`='$description',`grossweight`='$grossweight',`diamondweight`='$diamondweight',`shape`='$shape',`color`='$color',`clarity`='$clarity',`category`='$category',`comment`='$comment' where ID='$id'";
			 }
	
					
		 $res=mysqli_query($links, $query);
				
						if($res)
							{
								$_SESSION['msg']="Updated Successfully";
							   header('location:view-certificates.php');
							}
							else
							{
								echo "<script>alert('Data Updation failed');</script>";
							}
				}
					
			
		function delete($data, $links)
			{	
			    $deleteID=base64_decode($data);
				$query="delete from `vision` where ID='$deleteID'";
				$res=mysqli_query($links, $query);
				if($res)
					{
						$_SESSION['msg']="Deleted Successfully";
						header('location:view-certificates.php');
					}
				else
					{
						echo "<script>alert('Data Deletion failed');</script>";
					}
			}
			
		
			
		
 }
 ?>