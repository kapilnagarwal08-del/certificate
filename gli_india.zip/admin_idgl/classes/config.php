<?php 
$link = mysql_connect('localhost','articenc_koul','Techsite123#');
mysql_select_db('articenc_tech');
?>