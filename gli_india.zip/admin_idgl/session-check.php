<?php
session_start();
if($_SESSION['name']=='')
{
    echo "<script>location='login.php'</script>";
}
?>